def encode(js):
    '''
    I love Hiram
    '''
    return js+';\n/*After all,hiram is my hero*/\n'
