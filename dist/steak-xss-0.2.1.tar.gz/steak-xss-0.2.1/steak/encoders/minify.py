from jsmin import jsmin
def encode(js):
    return jsmin(js)
